- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.
*Apply after back up the existing resource files, recommend.

After applying the theme, be sure to run below batch file once the 
first time.

/Resources/Qs_tool/Qs_frogtool_listup_v13.bat

*Below folders will be created under the SD card.
 SEGA
 ATARI_NGP
 WONDERSWAN
 PCE
 MULTICORE

- This theme is different from others in that it is set to refer to 
above folders.

Other tools, including tadpole and frogtool, do not support these folders.
(* As of April 2025)
In addition, the order of the game system categories has been customized, 
so to update the list after adding a game (rebuild the game list), 
do not use other tools including tadpole and frogtool, but use the 
"Qs_tool" batch file instead.

/Resources/Qs_tool/Qs_frogtool_listup_v13.bat

*The usage (arguments to be given) is the same as frogtool.

- In case want to change the category of the game system,
that have prepared resource files for different patterns.
Please replace the resources as appropriate.
(For other patterns, please refer to the "#Screenshot" folder)
Also change the FoldernamX.ini (Foldername.ini) and folder,
Can change the category by rebuilding the list use tool.

- Four shortcuts is delete from the main menu on each system.
(Due to layout. )
If push A on mainmenu show "loading" screen, but as soon hide.

- Other points to note:
xfgle.hgp and swapfile.sys will be overwritten too.
Apply after back up the existing resource file, recommend.

- Since the game menu resources have been changed, 
if rebuild gamelist, 
Please use below batch file instead of using frogtool.

/Resources/Qs_tool/Qs_frogtool_listup_v13.bat

*The usage (arguments to be given) is the same as frogtool.

Then run Qs_frogtool_listup_v13.bat to rebuild the game list.
*If an error occurs during list reconstruction processing using a 
batch file, please contact @Q_ta with Discord.

