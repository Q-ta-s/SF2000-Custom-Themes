- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.

- In case want to change the category of the game system,
that have prepared resource files for different patterns.
Please replace the resources as appropriate.
(For other patterns, please refer to the "#Screenshot" folder)

- Four shortcuts is delete from the main menu on each system.
(Due to layout. )
If push A on mainmenu show "loading" screen, but as soon hide.

- Other points to note:
xfgle.hgp and swapfile.sys will be overwritten too.
Apply after back up the existing resource file, recommend.

*If have other any questions, please contact @Q_ta with Discord.
