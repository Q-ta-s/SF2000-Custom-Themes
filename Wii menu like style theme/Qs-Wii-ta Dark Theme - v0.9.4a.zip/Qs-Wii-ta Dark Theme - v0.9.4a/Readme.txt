- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.

- In case want to change the category of the game system,
that have prepared resource files for different patterns.
Please replace the resources as appropriate.
(For other patterns, please refer to the "#Screenshot" folder)
Also change the Foldername.ini folder and use frogtool etc,
Can change the category by rebuilding the list.

- Four shortcuts is delete from the main menu on each system.
(Due to layout. )
If push A on mainmenu show "loading" screen, but as soon hide.

- Other points to note:
xfgle.hgp and swapfile.sys will be overwritten too.
Apply after back up the existing resource file, recommend.

- Since the game menu resources have been changed, 
if rebuild gamelist, 
Please use below batch file instead of using frogtool.

/Resources/Qs_tool/Qs_frogtool_listup.bat

*The usage (arguments to be given) is the same as frogtool.

"MD"  folder: Place SEGA games. (MD/GG/SMS)
"GB"  folder: Place PC Engine games.
"GBC" folder: Place ATARI/LYNX/NGP etc games.
"GBA" folder: Place GBA/GB/COLOR games.
*Other above, it is OK to put the game to same category name folder.

Then run Qs_frogtool_listup.bat to rebuild the game list.
*If an error occurs during list reconstruction processing using a 
batch file, please contact @Q_ta with Discord.

----------------------------------------------------------------------
*The above batch file automates the troublesome movement of game below.
if rebuild gamelist with frogtool, place the game in the below folder.

"MD"  folder: Place GBA/GB/COLOR games.
"GB"  folder: Place PC Engine games.
"GBC" folder: Place SEGA games. (MD/GG/SMS)
"GBA" folder: Place ATARI/LYNX/NGP etc games.
*Other above, it is OK to put the game to same category name folder.

After rebuilding the list, place the game in the folder below.
"MD"  folder: Place SEGA games. (MD/GG/SMS)
"GB"  folder: Place PC Engine games.
"GBC" folder: Place ATARI/LYNX/NGP etc games.
"GBA" folder: Place GBA/GB/COLOR games.
*Other above, it is OK to put the game to same category name folder.

