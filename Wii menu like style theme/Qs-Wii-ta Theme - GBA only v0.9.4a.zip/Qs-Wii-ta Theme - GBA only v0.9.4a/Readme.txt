- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.

- This is a version that only displayed GBA category, and 
hide user settings.
The method for adding/removing games is different from normal.
(frogtool/tadpole is not required) 
Please follow the steps below. 

(1) Open /Resources/Foldername.ini, change the values ​​below, and save. 

  [Before change] 1 0 9 

  [After change ] 1 0 0 

(2) Place the game ROM file directly under the /ROMS folder of 
the SD card. 

(3) When you start SF2000, the screen will be slightly distorted, 
but the "USER GAME LIST" menu will be displayed, 
so press the A button to select it. 

(4) Once loading is complete, game addition/deletion
 (game list update) is complete.

(5) Close SF2000, open /Resources/Foldername.ini again, 
change the values ​​below, and save.

  [Before change] 1 0 0 

  [After change ] 1 0 9

- In case want to change the category of the game system,
that have prepared resource files for different patterns.
Please replace the resources as appropriate.
(For other patterns, please refer to the "#Screenshot" folder)

- Four shortcuts is delete from the main menu on each system.
(Due to layout. )
If push A on mainmenu show "loading" screen, but as soon hide.

- Other points to note:
xfgle.hgp and swapfile.sys will be overwritten too.
Apply after back up the existing resource file, recommend.

