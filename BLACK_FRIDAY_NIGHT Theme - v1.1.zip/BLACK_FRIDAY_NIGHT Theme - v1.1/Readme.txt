- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.
*Apply after back up the existing resource file, recommend.

- There is a stock boot logo in the "#bootlogo" folder, 
so please reflect it in bios/bisrv.asd.

- There is following files in the "#Screenshot" folder also, 
which may be useful. 

(1) In case replacing the four shortcut icons in the game menu
    with tool (such as tadpole), after If want to redecorate 
    the icons can use "icon_layer.png" in the "parts" folder.
    By layering a png image on top, can decorate the icon to 
    match this theme.
(2) Sample file with the title name of the game menu centered. 
    *This resource file is located in the "Resources" folder, 
    so please replace it as prefer.