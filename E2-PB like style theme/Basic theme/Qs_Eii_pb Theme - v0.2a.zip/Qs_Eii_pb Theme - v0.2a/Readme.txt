- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.
*Apply after back up the existing resource file, recommend.

After applying the theme, be sure to run below batch file once the 
first time.

/Resources/Qs_tool/Qs_frogtool_listup.bat

*"PCE" and "MULTICORE" folders will be created under the SD card.

- This theme is different from others in that it is set to refer to the 
"PCE" and "MULTICORE" folders.

Other tools, including tadpole and frogtool, do not support these folders.
(* As of September 2024)
In addition, the order of the game system categories has been customized, 
so to update the list after adding a game (rebuild the game list), 
do not use other tools including tadpole and frogtool, but use the 
"Qs_tool" batch file instead.

/Resources/Qs_tool/Qs_frogtool_listup.bat

*The usage (arguments to be given) is the same as frogtool.

- In case want to change the category of the game system,
that have prepared resource files for different patterns.
Please replace the resources as appropriate.
(For other patterns, please refer to the "#Screenshot" folder)
Also change the Foldername.ini folder and use "Qs_tool" batch file,
Can change the category by rebuilding the list.

- In the "#Screenshot" folder, there is a "Base png" folder, 
which contains image parts that are the base of the theme. 
By combining these, you can edit them to your liking. 
(You can use image editing software such as "Paint.Net" or "GIMP" to 
edit them.)
You can easily create theme resources by placing a character image, 
for example, on top of "fixas.ctp_base.png" as a layer, and then 
overlaying the "fixas.ctp_layer.png" image as a layer.
The created png image can be converted to an RGB565 resource on the 
"Generic Image Tool" site.

https://vonmillhausen.github.io/sf2000/tools/genericImageTool.htm
(*"Dithering" specify "0.5" for Strength.)

Let's reflect (replace) the converted resource file in the 
"Resources" folder on the SD card.

- Other points to note:
Since the game menu resources have been changed, 
if rebuild gamelist, 
Please use "Qs_tool" batch file instead of using tadpole / frogtool.
*If an error occurs during list reconstruction processing using a 
batch file, please contact @Q_ta with Discord.

----------------------------------------------------------------------
*The above batch file automates the troublesome movement of game below.
if rebuild gamelist with frogtool, place the game in the below folder.

"MD"  folder: Place GBA/GB/COLOR games.
"GB"  folder: Place PC Engine games.
"GBC" folder: Place SEGA games. (MD/GG/SMS)
"GBA" folder: Place games other than the above categories.
*Other above, it is OK to put the game to same category name folder.

After rebuilding the list, place the game in the folder below.
"MD"  folder: Place SEGA games. (MD/GG/SMS)
"PCE" folder: Place PC Engine games.
"GBA" folder: Place GBA/GB/COLOR games.
"MULTICORE" folder: Place games other than the above categories.
*Other above, it is OK to put the game to same category name folder.
