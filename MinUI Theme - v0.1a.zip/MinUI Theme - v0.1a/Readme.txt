MinUI theme

- This file contains only the difference of theme changes.
Overwrite the official resource file with the this difference files,
apply the theme.
*Apply after back up the existing resource file, recommend.

- There is a boot logo of MinUI in the "#bootlogo" folder, 
so please reflect it in /bios/bisrv.asd.

- The game list indicator is MinUI style, 
but if it is difficult to see, there are two other indicator patterns 
available. Can switch between indicators by executing below batch, 
so please switch mode to your preference.

/Resources/Qs_tool/Qs_switch_list_indicator.bat

- Other points to note:
*swapfile.sys will be overwritten.
Apply after back up the existing resource file, recommend.

*Apologize to those who have selected Hebrew (Israel) or 
Arabic (Saudi Arabia). Please replace the font with the one below. 
(This will fix the font display.)
Please delete /Resources/Arial_en.ttf, and rename 
/Resources/Arial_en.ttf_orig to /Resources/Arial_en.ttf.
The above renaming will replace it with the standard font.

--------------------------------------------------------------------
*This is an unofficial theme that is not directly related 
to the original MinUI, as it is a theme for SF2000. 
(Original MinUI:)
https://github.com/shauninman/MinUI
In the unlikely event that a problem occurs, please note 
that the original author of the official MinUI will not be 
held responsible for any consequences that may occur.
